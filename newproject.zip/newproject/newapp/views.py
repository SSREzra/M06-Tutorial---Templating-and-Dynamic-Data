from django.shortcuts import render
from django.http import HttpResponse

# Create your views here
def index(request):
    mydictionary = {'key':'Please sign in','new_key:'Welcome To Ivy Tech'}
    return render(request, 'signin.html', context = mydictionary)